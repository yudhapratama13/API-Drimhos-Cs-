<?php 
	
	include ('config.php');

	$id_transaksi   = $_POST['id_transaksi'];
	
	class emp{}
	
	if (empty($id_transaksi)) { 
		$response = new emp();
		$response->success = 0;
		$response->message = "1. Data Tidak Terhapus: "; 
		die(json_encode($response));
	} else {
	    
	    $cek_id_cs = mysql_query("SELECT * FROM transactions WHERE transaction_id = '$id_transaksi' ");
	    $data_cs     = mysql_fetch_array($cek_id_cs);
	    $costumer_id = $data_cs['customer_id'];
	    
	    $cek_jml_transaksi = mysql_query("SELECT * FROM costumers WHERE costumer_id = '$costumer_id' ");
	    $data_cek       = mysql_fetch_array($cek_jml_transaksi);
	    $jml_trans_baru = $data_cek['jumlah_transaksi'] - 1;
	    
	    $update_jml_trans = mysql_query("UPDATE costumers SET jumlah_transaksi = '$jml_trans_baru' WHERE costumer_id = '$costumer_id' ");
	    
	    $hapus_transaksi = mysql_query("DELETE FROM transactions WHERE transaction_id = '$id_transaksi' ");
	    
		$hapus_amount = mysql_query("DELETE FROM transactions_amount WHERE transaction_id = '$id_transaksi' ");
		
		if ($hapus_transaksi && $hapus_amount) {
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Transaksi Berhasil di Hapus";
			die(json_encode($response));
		} else{ 
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Transaksi Tidak Terhapus";
			die(json_encode($response)); 
		}	
	}

?>