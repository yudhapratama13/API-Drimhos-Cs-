<?php 

	include('config.php');

	class emp{}

	if (!$_POST['id_pelanggan'] || !$_POST['id_cs'] || !$_POST['nama_produk'] || !$_POST['jumlah_produk'] ) {
		$response = new emp();
		$response->success = 0;
		$response->message = 'Kolom Tidak Boleh Kosong';
		die(json_encode($response));
	}
	else{

		$id_pelanggan     = $_POST['id_pelanggan'];
		$id_cs 			  = $_POST['id_cs'];
		$tgl_transaksi    = $_POST['tgl_transaksi'];
		$nama_produk      = $_POST['nama_produk'];
		$jumlah_produk    = $_POST['jumlah_produk'];

		$cek_barang = mysql_query("SELECT * FROM products WHERE product_title_general = '$nama_produk'");
		$barang 	= mysql_fetch_array($cek_barang);
		$id_barang  = $barang['product_id'];

        $cek_max      = mysql_query("SELECT MAX(transaction_id) AS id_max FROM transactions WHERE transaction_date = '$tgl_transaksi' AND user_id = '$id_cs' AND customer_id = '$id_pelanggan' ");
        $data_max     = mysql_fetch_array($cek_max);
		$id_transaksi = $data_max['id_max'];

		$transaksi_amount = mysql_query("INSERT INTO transactions_amount VALUES ('', '$id_transaksi', '$id_barang', '$jumlah_produk')");

		if ($transaksi_amount) {
			$response = new emp();
			$response->success = 1;
			$response->message = 'Transaksi Berhasil di Simpan';
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = 'Transaksi Gagal di Simpan';
			die(json_encode($response));
		}
	}

?>