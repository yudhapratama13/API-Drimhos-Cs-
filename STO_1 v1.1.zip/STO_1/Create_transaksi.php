<?php 

	include('config.php');

	date_default_timezone_set('Asia/Jakarta');
	$jam_transaksi 	 = date('H:i:s');
	$id_pelanggan  	 = $_POST['id_pelanggan'];
	$id_cs         	 = $_POST['id_cs'];
	$tgl_transaksi   = $_POST['tanggal_transaksi'];
	$nama_pengiriman = $_POST['nama_pengiriman'];
	$biaya_kirim     = $_POST['biaya_kirim'];
	$total_bayar     = $_POST['total_bayar'];
	$pembayaran      = $_POST['pembayaran'];

	$id_produk 		 = $_POST['id_produk'];
	$jumlah_produk   = $_POST['jumlah_produk'];

	class emp{}

	if (empty($id_produk) || empty($jumlah_produk) || empty($nama_pengiriman) || empty($biaya_kirim) || empty($total_bayar) || empty($pembayaran) || empty($tgl_transaksi)) {
		$response = new emp();
		$response->success = 0;
		$response->message = 'Kolom Tidak Boleh Kosong';
		die(json_encode($response));
	}
	else{
	    
	    $melacak_id_cos = mysql_query("SELECT * FROM costumers WHERE costumer_id = '$id_pelanggan'");
        $baris_id_cos = mysql_fetch_array($melacak_id_cos);
    
        // mengecek berapa kali transaksi
        $nilai_kelas = 1 + $baris_id_cos['jumlah_transaksi'];

        // update insert kelas
        $insert_kelas = mysql_query ("UPDATE costumers SET 
        jumlah_transaksi = '$nilai_kelas' 
        WHERE costumer_id = '$id_pelanggan' ");
	    
		$query = mysql_query("INSERT INTO transactions VALUES ('', '$jam_transaksi', '$tgl_transaksi', '$id_pelanggan', '$id_cs', '$nama_pengiriman', '$biaya_kirim', '$total_bayar', '$pembayaran', NULL, 'belum diterima') ");

        $melacak_id_barang = mysql_query("SELECT * FROM products WHERE product_title_general = '$id_produk'");
            $baris_id_barang = mysql_fetch_array($melacak_id_barang);
            $product_id = $baris_id_barang['product_id'];
    
            $cek_max_id   = mysql_query("SELECT * FROM transactions WHERE transaction_id IN (SELECT MAX(transaction_id) FROM transactions)");
            $data_max_id  = mysql_fetch_array($cek_max_id);
            $id_transaksi = $data_max_id['transaction_id'];
    
            $transaksi    = mysql_query("INSERT INTO transactions_amount VALUES ('', '$id_transaksi', '$product_id', '$jumlah_produk') ");

		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = 'Transaksi Berhasil di Simpan';
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = 'Transaksi Gagal di Simpan';
			die(json_encode($response));
		}
	}

?>