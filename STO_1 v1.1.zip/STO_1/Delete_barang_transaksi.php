<?php 
	
	include ('config.php');

	$transactions_amount_id   = $_POST['transactions_amount_id'];
	
	class emp{}
	
	if (empty($transactions_amount_id)) { 
		$response = new emp();
		$response->success = 0;
		$response->message = "Id Transaction Amount Kosong: "; 
		die(json_encode($response));
	} else {
		$query = mysql_query("DELETE FROM transactions_amount WHERE transactions_amount_id = '$transactions_amount_id'");
		
		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Barang Berhasil di Hapus";
			die(json_encode($response));
		} else{ 
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Tidak Terhapus";
			die(json_encode($response)); 
		}	
	}

?>