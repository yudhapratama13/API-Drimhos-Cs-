<?php 

	include('config.php');

	$id_cs 			= $_POST['id_cs'];
	$tgl_leads 		= $_POST['tgl_leads'];
	$leads 			= $_POST['leads'];

	class emp{}

	if (empty($id_cs) || empty($tgl_leads)) {
		$response = new emp();
		$response->success = 0;
		$response->message = 'Kolom Tidak Boleh Kosong';
		die(json_encode($response));
	}
	else{

		$query = mysql_query("INSERT INTO leads VALUES ('', '$tgl_leads', '$id_cs', '$leads') ");

		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = 'Leads Berhasil di Simpan';
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = 'Leads Gagal di Simpan';
			die(json_encode($response));
		}
	}

?>