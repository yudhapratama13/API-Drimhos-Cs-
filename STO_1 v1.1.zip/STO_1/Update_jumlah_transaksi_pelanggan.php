<?php 

	include ('config.php');

	$id_pelanggan1  = $_POST['id_pelanggan'];
	$id_cs1 		= $_POST['id_cs'];

	class emp{}

		if (empty($id_pelanggan1) || empty($id_cs1)) {
			$response = new emp();
			$response->success = 0;
			$response->message = "Id Costumer atau Id User Kosong";
			die(json_encode($response));
		}
		else{

            $id_pelanggan     = $_POST['id_pelanggan'];
    		$id_cs 			  = $_POST['id_cs'];
    		$tgl_transaksi    = $_POST['tgl_transaksi'];
    		$jam_transaksi    = date('h:i:sa');
    		$nama_pengiriman  = $_POST['nama_pengiriman'];
    		$biaya_kirim      = $_POST['biaya_kirim'];
    		$total_bayar 	  = $_POST['total_bayar'];
    		$pembayaran 	  = $_POST['pembayaran'];
			
			$transaksi = mysql_query("INSERT INTO transactions VALUES ('', '$jam_transaksi', '$tgl_transaksi', '$id_cs', '$id_pelanggan', '$nama_pengiriman', '$biaya_kirim', '$total_bayar', '$pembayaran', '', 'belum diterima') ");

			if ($transaksi) {
			    
			    $cek   = mysql_query("SELECT * FROM costumers WHERE costumer_id = '$id_pelanggan' ");
			    $data  = mysql_fetch_array($cek);

			    $jmlh_transaksi_baru = $data['jumlah_transaksi'] + 1;

			    $query = mysql_query("UPDATE costumers SET jumlah_transaksi = '$jmlh_transaksi_baru' WHERE costumer_id = '$id_pelanggan' ");
			    
				$response = new emp();
				$response->success = 1;
				$response->message = "Transaksi Berhasil di Simpan";
				die(json_encode($response));
			}
			else{
				$response = new emp();
				$response->success = 0;
				$response->message = "Transaksi Gagal di Simpan";
				die(json_encode($response));
			}

		}

?>