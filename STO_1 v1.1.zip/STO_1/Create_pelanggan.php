<?php 

	include('config.php');

	$nama_pelanggan = $_POST['nama_pelanggan'];
	$alamat 		= $_POST['alamat'];
	$kecamatan 		= $_POST['kecamatan'];
	$kabupaten 		= $_POST['kabupaten'];
	$provinsi 		= $_POST['provinsi'];
	$kode_pos 		= $_POST['kode_pos'];
	$no_tlp 		= $_POST['no_tlp'];
	$status_aktif 	= date('Y-m-d');

	class emp{}

	if (empty($nama_pelanggan) || empty($alamat) || empty($kecamatan) || empty($kabupaten) || empty($provinsi) || empty($kode_pos) || empty($no_tlp)) {
		$response = new emp();
		$response->success = 0;
		$response->message = 'Kolom Tidak Boleh Kosong';
		die(json_encode($response));
	}
	else{
		$query = mysql_query("INSERT INTO costumers VALUES ('', '$nama_pelanggan', '$alamat', '$kecamatan', '$kabupaten', '$provinsi', '$kode_pos', '$no_tlp', '$status_aktif', 0) ");

		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = 'Pelanggan Berhasil di Simpan';
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = 'Pelanggan Gagal di Simpan';
			die(json_encode($response));
		}
	}

?>