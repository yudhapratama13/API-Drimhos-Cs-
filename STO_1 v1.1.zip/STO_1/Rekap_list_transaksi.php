<?php 

	include('config.php');

 
        
        $id_cs      = $_POST['id_cs'];
    	$tglAwal 	= $_POST['tglAwal'];
    	$tglAkhir 	= $_POST['tglAkhir'];
        $namaPlg    = $_POST['namaPlg'];
        
        if($namaPlg == 'Pilih Semua'){
            $query =mysql_query("SELECT * FROM transactions INNER JOIN costumers ON costumers.costumer_id = transactions.customer_id WHERE user_id = '$id_cs' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' ORDER BY transaction_date DESC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);    
        }
        else{
            
            $query_costumer = mysql_fetch_array(mysql_query("SELECT * FROM costumers WHERE costumer_name = '$namaPlg'"));
            $id_costumer = $query_costumer['costumer_id'];
            
            $query =mysql_query("SELECT * FROM transactions INNER JOIN costumers ON costumers.costumer_id = transactions.customer_id WHERE user_id = '$id_cs' AND customer_id = '$id_costumer' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' ORDER BY transaction_date DESC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
        }
        
?>