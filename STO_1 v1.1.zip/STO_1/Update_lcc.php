<?php 

	include ('config.php');

	$leads_id     = $_POST['leads_id'];
	$leads_amount = $_POST['leads_amount'];

	class emp{}

	if (empty($leads_id) || empty($leads_amount)){

		$response = new emp();
		$response->success = 0;
		$response->message = "Kolom Tidak Boleh Kosong";
		die(json_encode($response));
	}
	else{

		$query = mysql_query("UPDATE leads SET 
								leads_amount   = '$leads_amount'
								WHERE leads_id = '$leads_id' 
							");
		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Leads Berhasil di Update";
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Leads Gagal di Update";
			die(json_encode($response));
		}

	}

?>