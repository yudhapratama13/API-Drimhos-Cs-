<?php 
	
	include ('config.php');

	$transaksi = 'Loyal';

	class emp{}

	if (empty($transaksi)) {
		$response = new emp();
		$response->success = 0;
		$response->message = "Error Mengambil Data";
		die(json_encode($response));
	}
	else{

		if ($transaksi == 'Loyal') {
			$query = mysql_query("SELECT * FROM costumers WHERE jumlah_transaksi > 5 ORDER BY costumer_id DESC");
		}
		elseif ($transaksi == 'Costumer') {
			$query = mysql_query("SELECT * FROM costumers WHERE jumlah_transaksi >= 2 AND jumlah_transaksi <= 5 ORDER BY costumer_id DESC");
		}
		elseif ($transaksi == 'Buyer') {
			$query = mysql_query("SELECT * FROM costumers WHERE jumlah_transaksi = 1 ORDER BY costumer_id DESC");
		}
		else{
			$query = mysql_query("SELECT * FROM costumers ORDER BY costumer_id DESC");
		}

		$row   = mysql_fetch_array($query);
		
		if(!empty($row)){
		    $json  = array();
    		while ($row = mysql_fetch_assoc($query)) {
    			$json[] = $row;
    		}
     		echo json_encode($json);
    		mysql_close($connect);
		}
		else{
		 	$response = new emp();
		 	$response->success = 0;
		 	$response->message = "Filter Kelas Loyal Tidak di Temukan";
		 	die(json_encode($response));
		 }
		
		

	}

?>