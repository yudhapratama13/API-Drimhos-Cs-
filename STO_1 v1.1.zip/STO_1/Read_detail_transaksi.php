<?php 
	
	include ('config.php');

    $id_transaksi   = $_POST['id_transaksi'];

	class emp{}

	if (empty($id_transaksi)) {
		$response = new emp();
		$response->success = 0;
		$response->message = "Error Mengambil Data";
		die(json_encode($response));
	}
	else{

		$query = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.	product_id = transactions_amount.product_id INNER JOIN costumers ON costumers.costumer_id = transactions.customer_id WHERE transactions.transaction_id = '$id_transaksi' ");
		$row   = mysql_fetch_array($query);

		if (!empty($row)) {
		 	$response = new emp();
		 	$response->success = 1;
		 	$response->costumer_name    	 = $row['costumer_name'];
		 	$response->transaction_date 	 = $row['transaction_date'];
		 	$response->costumer_address      = $row['costumer_address'];
		 	$response->costumer_sub_district = $row['costumer_sub_district'];
		 	$response->costumer_district     = $row['costumer_district'];
		 	$response->costumer_province     = $row['costumer_province'];
		 	$response->costumer_postal_code  = $row['costumer_postal_code'];
		 	$response->costumer_phone_number = $row['costumer_phone_number'];
		 	$response->total_price      	 = $row['total_price'];
		 	$response->shipping_name         = $row['shipping_name'];
		 	$response->payment               = $row['payment'];
		 	$response->shipping_fee          = $row['shipping_fee'];
		 	$response->receipt_number        = $row['receipt_number'];
		 	$response->transaction_status    = $row['transaction_status'];
		 	die(json_encode($response));
		 }
		 else{
		 	$response = new emp();
		 	$response->success = 0;
		 	$response->message = "Error Mengambil Data";
		 	die(json_encode($response));
		 } 

	}

?>