<?php 

	include('config.php');

    if(!$_POST['id_cs'] || !$_POST['tglAwal'] || !$_POST['tglAkhir']){
        echo"Kosong";
    }
    else{
        
        $id_cs      = $_POST['id_cs'];
    	$tglAwal 	= $_POST['tglAwal'];
    	$tglAkhir 	= $_POST['tglAkhir'];
        
        $query = mysql_query("SELECT * FROM leads WHERE user_id = '$id_cs' AND leads_date BETWEEN '$tglAwal' AND '$tglAkhir' ORDER BY leads_date DESC");
    	$json  = array();
    	while ($row = mysql_fetch_assoc($query)) {
    		$json[] = $row;
    	}
    	echo json_encode($json);
    	mysql_close($connect);
        
    }

?>